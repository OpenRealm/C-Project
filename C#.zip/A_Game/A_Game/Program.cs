using System;

namespace A_Game
{
	class MainClass
	{
		public static void Restartls (ref string ls, ref string d) {
			ls = d;
		}
		public static void AB (ref string AA1, ref string AA2 , ref string AA3, ref string AA4, ref string AB1, ref string AB2, ref string AB3, ref string AB4, ref string AC1, ref string AC2, ref string AC3, ref string AC4, ref string AD1, ref string AD2, ref string AD3, ref string AD4, ref string A1, ref string A2, ref string A3, ref string A4, ref string B1, ref string B2, ref string B3, ref string B4, ref string C1, ref string C2, ref string C3, ref string C4, ref string D1, ref string D2, ref string D3, ref string D4) {
			AA1 = A1;
			AA2 = A2;
			AA3 = A3;
			AA4 = A4;
			AB1 = B1;
			AB2 = B2;
			AB3 = B3;
			AB4 = B4;
			AC1 = C1;
			AC2 = C2;
			AC3 = C3;
			AC4 = C4;
			AD1 = D1;
			AD2 = D2;
			AD3 = D3;
			AD4 = D4;
		}
		public static void AA (ref string AA1, ref string AA2 , ref string AA3, ref string AA4, ref string AB1, ref string AB2, ref string AB3, ref string AB4, ref string AC1, ref string AC2, ref string AC3, ref string AC4, ref string AD1, ref string AD2, ref string AD3, ref string AD4, ref string A1, ref string A2, ref string A3, ref string A4, ref string B1, ref string B2, ref string B3, ref string B4, ref string C1, ref string C2, ref string C3, ref string C4, ref string D1, ref string D2, ref string D3, ref string D4) {
			A1 = AA1;
			A2 = AA2;
			A3 = AA3;
			A4 = AA4;
			B1 = AB1;
			B2 = AB2;
			B3 = AB3;
			B4 = AB4;
			C1 = AC1;
			C2 = AC2;
			C3 = AC3;
			C4 = AC4;
			D1 = AD1;
			D2 = AD2;
			D3 = AD3;
			D4 = AD4;
		}
		public static void Fin (ref int nul, ref int brek, ref int j1, ref int j2,ref string X, ref string O, ref string A1, ref string A2, ref string A3, ref string A4, ref string B1, ref string B2, ref string B3, ref string B4, ref string C1, ref string C2, ref string C3, ref string C4, ref string D1, ref string D2, ref string D3, ref string D4) {
			if (A1 == X) {
				if (A2 == X) {
					if (A3 == X) {
						if (A4 == X) {
							j1 = 1;
							brek = 1;
						}
					}
				}
			}
			if (A1 == X | A1 == O) {
				if (A2 == X | A2 == O) {
					if (A3 == X | A3 == O) {
						if (A4 == X | A4 == O) {
							if (B1 == X | B1 == O) {
								if (B2 == X | B2 == O) {
									if (B3 == X | B3 == O) {
										if (B4 == X | B4 == O) {
											if (C1 == X | C1 == O) {
												if (C2 == X | C2 == O) {
													if (C3 == X | C3 == O) {
														if (C4 == X | C4 == O) {
															if (D1 == X | D1 == O) {
																if (D2 == X | D2 == O) {
																	if (D3 == X | D3 == O) {
																		if (D4 == X | D4 == O) {
																			nul = 1;
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		public static void Grille (ref string A1, ref string A2, ref string A3, ref string A4, ref string B1, ref string B2, ref string B3, ref string B4, ref string C1, ref string C2, ref string C3, ref string C4, ref string D1, ref string D2, ref string D3, ref string D4) {
			Console.WriteLine (" ");
			Console.WriteLine ("|A|B|C|D|");
			Console.WriteLine ("1" + A1 +" "+ B1 +" "+ C1 +" "+ D1 + "|");
			Console.WriteLine ("2" + A2 +" "+ B2 +" "+ C2 +" "+ D2 + "|");
			Console.WriteLine ("3" + A3 +" "+ B3 +" "+ C3 +" "+ D3 + "|");
			Console.WriteLine ("4" + A4 +" "+ B4 +" "+ C4 +" "+ D4 + "|");
			Console.WriteLine ("|A|B|C|D|");
			Console.WriteLine (" ");
		}
		public static void Tab (ref string X, ref string O,ref string lb, ref string ls, ref string A1, ref string A2, ref string A3, ref string A4, ref string B1, ref string B2, ref string B3, ref string B4, ref string C1, ref string C2, ref string C3, ref string C4, ref string D1, ref string D2, ref string D3, ref string D4) {
			if (ls == "A1") {
				if (A1 == " ") {
					A1 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "A2") {
				if (A2 == " ") {
					A2 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "A3") {
				if (A3 == " ") {
					A3 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "A4") {
				if (A4 == " ") {
					A4 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "B1") {
				if (B1 == " ") {
					B1 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "B2") {
				if (B2 == " ") {
					B2 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "B3") {
				if (B3 == " ") {
					B3 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "B4") {
				if (B4 == " ") {
					B4 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "C1") {
				if (C1 == " ") {
					C1 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "C2") {
				if (C2 == " ") {
					C2 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "C3") {
				if (C3 == " ") {
					C3 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "C4") {
				if (C4 == " ") {
					C4 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "D1") {
				if (D1 == " ") {
					D1 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "D2") {
				if (D2 == " ") {
					D2 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "D3") {
				if (D3 == " ") {
					D3 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (ls == "D4") {
				if (D4 == " ") {
					D4 = X;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "A1") {
				if (A1 == " ") {
					A1 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "A2") {
				if (A2 == " ") {
					A2 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "A3") {
				if (A3 == " ") {
					A3 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "A4") {
				if (A4 == " ") {
					A4 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "B1") {
				if (B1 == " ") {
					B1 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "B2") {
				if (B2 == " ") {
					B2 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "B3") {
				if (B3 == " ") {
					B3 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "B4") {
				if (B4 == " ") {
					B4 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "C1") {
				if (C1 == " ") {
					C1 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "C2") {
				if (C2 == " ") {
					C2 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "C3") {
				if (C3 == " ") {
					C3 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "C4") {
				if (C4 == " ") {
					C4 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "D1") {
				if (D1 == " ") {
					D1 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "D2") {
				if (D2 == " ") {
					D2 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "D3") {
				if (D3 == " ") {
					D3 = O;
				} 
				else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			}
			if (lb == "D4") {
				if (D4 == " ") {
					D4 = O;
				} else {
					Console.WriteLine ("--------------------------------------------------------------------------------");
					Console.WriteLine ("Cette case est occupée !                                                        ");
					Console.WriteLine ("--------------------------------------------------------------------------------");
				}
			} 
		}
		public static void Main (string[] args)
		{
			Console.BackgroundColor = ConsoleColor.White;
			Console.ForegroundColor = ConsoleColor.Black;
			string A1 = " ";
			string B1 = " ";
			string C1 = " ";
			string D1 = " ";
			string A2 = " ";
			string B2 = " ";
			string C2 = " ";
			string D2 = " ";
			string A3 = " ";
			string B3 = " ";
			string C3 = " ";
			string D3 = " ";
			string A4 = " ";
			string B4 = " ";
			string C4 = " ";
			string D4 = " ";
			int nul = 0;
			string X = "X";
			string O = "O";
			bool part = true;
			int j1 = 0;
			int j2 = 0;
			int brek = 0;
			string lb = " ";
			while (true) {
				Console.WriteLine ("--------------------------------------------------------------------------------");
				Console.WriteLine ("Nommez vous :                                                                   ");
				Console.WriteLine ("--------------------------------------------------------------------------------");
				Console.Write (">>> ");
				string name1 = Console.ReadLine ();
				Console.BackgroundColor = ConsoleColor.DarkRed;
				Console.WriteLine ("Joueur 1 : " + name1+ "                                                                   ");
				Console.WriteLine ("--------------------------------------------------------------------------------");
				Console.Write (">>> ");
				string name2 = Console.ReadLine ();
				Console.BackgroundColor = ConsoleColor.DarkBlue;
				Console.WriteLine ("Joueur 2 : " + name2+"                                                                    ");
				Console.WriteLine ("--------------------------------------------------------------------------------");
				while (part) {
					Grille (ref A1, ref A2, ref A3, ref A4, ref B1, ref B2, ref B3, ref B4, ref C1, ref C2, ref C3, ref C4, ref D1, ref D2, ref D3, ref D4);
					Console.Write (name1 + " : ");
					string ls = Console.ReadLine ();
					Tab (ref X, ref O,ref lb, ref ls, ref A1, ref A2, ref A3, ref A4, ref B1, ref B2, ref B3, ref B4, ref C1, ref C2, ref C3, ref C4, ref D1, ref D2, ref D3, ref D4);
					ls = " ";
					Grille (ref A1, ref A2, ref A3, ref A4, ref B1, ref B2, ref B3, ref B4, ref C1, ref C2, ref C3, ref C4, ref D1, ref D2, ref D3, ref D4);
					Console.Write (name2 + " : ");
					string ld = Console.ReadLine ();
					lb = ld;
					ls = " ";
					Tab (ref X, ref O,ref lb, ref ls, ref A1, ref A2, ref A3, ref A4, ref B1, ref B2, ref B3, ref B4, ref C1, ref C2, ref C3, ref C4, ref D1, ref D2, ref D3, ref D4);
					lb = " ";
					Fin (ref nul, ref brek, ref j1, ref j2,ref X, ref O, ref A1, ref A2, ref A3, ref A4, ref B1, ref B2, ref B3, ref B4, ref C1, ref C2, ref C3, ref C4, ref D1, ref D2, ref D3, ref D4);
					if (brek == 1) {
						break;
					}
				}
				if (j1 == 1) {
					Console.WriteLine (name1 + " a gagné !!!                                                                                                                                                                        ");
				}
				if (j2 == 1) {
					Console.WriteLine (name2 + " a gagné !!!                                                                                                                                                                        ");
				}
				if (nul == 1) {
					Console.WriteLine ("Match Nul !!!                                                                                                                                                                        ");
				}
			}
		}
	}
}

using System;

namespace Pix
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write ("   ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.WriteLine ("      ");
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write (" ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.Write ("  ");
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write ("      ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.WriteLine ("  ");
			Console.Write (" ");
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write ("          ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.WriteLine (" ");
			Console.Write (" ");
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write ("          ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.WriteLine (" ");
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write (" ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.Write ("  ");
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write ("      ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.WriteLine ("  ");
			Console.BackgroundColor = ConsoleColor.Black;
			Console.Write ("   ");
			Console.BackgroundColor = ConsoleColor.Magenta;
			Console.WriteLine ("      ");
		}
	}
}
